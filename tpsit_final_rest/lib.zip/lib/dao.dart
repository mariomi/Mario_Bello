import 'package:floor/floor.dart';
import 'model.dart';

@dao
abstract class AnimalDao {
  @Query('SELECT * FROM Animals')
  Future<List<Animal>> findAllAnimals();

  @Query('SELECT * FROM Animals WHERE AnimalID = :id')
  Future<Animal?> findAnimalById(int id);

  @insert
  Future<void> insertAnimal(Animal animal);

  @update
  Future<void> updateAnimal(Animal animal);

  @delete
  Future<void> deleteAnimal(Animal animal);
}

@dao
abstract class UserDao {
  @Query('SELECT * FROM users')
  Future<List<User>> findAllUsers();

  @Query('SELECT * FROM users WHERE userID = :id')
  Future<User?> findUserById(int id);

  @insert
  Future<void> insertUser(User user);

  @update
  Future<void> updateUser(User user);

  @delete
  Future<void> deleteUser(User user);
}

@dao
abstract class TodoDao {
  @Query('SELECT * FROM Todo')
  Future<List<Todo>> getTodos();

  @Query('SELECT * FROM Todo WHERE id = :id')
  Future<Todo?> findTodoById(int id);

  @insert
  Future<void> insertTodo(Todo item);

  @insert
  Future<void> insertTodos(List<Todo> items);

  @update
  Future<void> updateTodo(Todo item);

  @update
  Future<void> updateTodos(List<Todo> items);

  @delete
  Future<void> deleteTodo(Todo item);

  @delete
  Future<void> deleteTodos(List<Todo> items);
}
