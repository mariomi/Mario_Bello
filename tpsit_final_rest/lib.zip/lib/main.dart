import 'dart:convert';
import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'next_page.dart';
import 'dao.dart';
import 'database.dart';
import 'model.dart';

String ip = "192.168.1.6";

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late final AppDatabase database;
  late final UserDao userDao;
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  String errorMessage = '';
  bool showRegistrationPanel = false;

  @override
  void initState() {
    super.initState();
    initdatabase();
  }

  Future<void> initdatabase() async {
    database = await $FloorAppDatabase.databaseBuilder('database.db').build();
    userDao = database.userDao;
  }

  Future<bool> authenticateUser(String username, String password) async {
    final Map<String, String> data = {
      'username': username,
      'password': password,
    };

    var url = Uri.parse('http://' + ip + ':3000/api/users/authenticate');
    var response = await http.post(url,
        body: json.encode(data), headers: {'Content-Type': 'application/json'});

    print('Login response status: ${response.statusCode}');
    print('Login response body: ${response.body}');

    if (response.headers['content-type']?.contains('application/json') ==
        true) {
      dynamic decodebody = jsonDecode(response.body);
      print('Decoded body: $decodebody');

      if (decodebody != null &&
          decodebody is Map<String, dynamic> &&
          decodebody.containsKey('UserID')) {
        final int userId = decodebody['UserID'];
        if (userId != null) {
          var url = Uri.parse(
              'http://' + ip + ':3000/api/users/' + userId.toString());
          var response = await http
              .get(url, headers: {'Content-Type': 'application/json'});
          bool isUserInDb = false;

          await userDao.findUserById(userId).then((value) {
            if (value == null) {
              isUserInDb = true;
            }
          });

          if (isUserInDb) {
            dynamic decodebody2 = jsonDecode(response.body);
            if (decodebody2 != null &&
                decodebody2 is List<dynamic> &&
                decodebody2.isNotEmpty) {
              Map<String, dynamic> userRecord = decodebody2[0];
              User user = User(
                  UserID: userId,
                  username: userRecord['username'],
                  Email: userRecord['Email'],
                  PasswordHash: userRecord['PasswordHash'],
                  isAdmin: userRecord['isAdmin'] == 1,
                  RegistrationDate: userRecord['RegistrationDate']);
              userDao.insertUser(user);
              userDao.findAllUsers().then((value) => print(value[0]));
            }
          }
          return true;
        }
      } else if (decodebody.containsKey('message')) {
        setState(() {
          errorMessage = decodebody['message'];
        });
      } else {
        setState(() {
          errorMessage = 'Unexpected response format';
        });
      }
    } else {
      setState(() {
        errorMessage = 'Unexpected response format: ${response.body}';
      });
    }
    return false;
  }

  Future<bool> registerUser(
      String username, String password, String email) async {
    final Map<String, dynamic> dataUser = {
      'Email': email,
      'username': username,
      'PasswordHash': password, // Password is plain text now
      'isAdmin': 0 // Set isAdmin to 0 by default
    };

    var url = Uri.parse('http://' + ip + ':3000/api/users');
    var response = await http.post(url,
        body: json.encode(dataUser),
        headers: {'Content-Type': 'application/json'});

    print('Registration response status: ${response.statusCode}');
    print('Registration response body: ${response.body}');

    if (response.statusCode == 201) {
      return true;
    } else {
      return false;
    }
  }

  void login() async {
    var username = usernameController.text;
    var password = passwordController.text;

    bool isAuthenticated = await authenticateUser(username, password);

    if (isAuthenticated) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => AnimalListWidget()),
      );
    } else {
      setState(() {
        errorMessage = 'Invalid credentials. Please try again.';
      });
    }
  }

  void register() async {
    var username = usernameController.text;
    var password = passwordController.text;
    var email = emailController.text;

    bool isRegistered = await registerUser(username, password, email);

    if (isRegistered) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Registration Successful'),
            content: Text('You have been successfully registered.'),
            actions: [
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Registration Failed'),
            content: Text('Failed to register. Please try again.'),
            actions: [
              TextButton(
                child: Text('OK'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: usernameController,
              decoration: InputDecoration(
                labelText: 'Username',
              ),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(
                labelText: 'Password',
              ),
              obscureText: true,
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              child: Text('Login'),
              onPressed: login,
            ),
            SizedBox(height: 8.0),
            ElevatedButton(
              child: Text('Register'),
              onPressed: () {
                setState(() {
                  showRegistrationPanel = true;
                });
              },
            ),
            SizedBox(height: 8.0),
            Text(
              errorMessage,
              style: TextStyle(
                color: Colors.red,
              ),
            ),
            if (showRegistrationPanel)
              Column(
                children: [
                  TextField(
                    controller: emailController,
                    decoration: InputDecoration(
                      labelText: 'Email',
                    ),
                  ),
                  TextField(
                    controller: usernameController,
                    decoration: InputDecoration(
                      labelText: 'Username',
                    ),
                  ),
                  TextField(
                    controller: passwordController,
                    decoration: InputDecoration(
                      labelText: 'Password',
                    ),
                    obscureText: true,
                  ),
                  SizedBox(height: 8.0),
                  ElevatedButton(
                    child: Text('Register'),
                    onPressed: register,
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    home: LoginPage(),
  ));
}
