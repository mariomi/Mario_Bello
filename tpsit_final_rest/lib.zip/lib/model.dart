import 'package:floor/floor.dart';

@Entity(tableName: 'users')
class User {
  User({
    required this.UserID,
    required this.username,
    required this.Email,
    required this.PasswordHash,
    required this.isAdmin,
    required this.RegistrationDate,
  });

  @primaryKey
  final int? UserID;

  final String username;
  final String Email;
  final String PasswordHash;
  final bool isAdmin;
  final String RegistrationDate;
}

@Entity(tableName: 'animals')
class Animal {
  Animal({
    required this.AnimalID,
    required this.Name,
    required this.Species,
    this.Breed,
    this.Age,
    required this.Gender,
    this.Description,
    this.PhotoUrl,
    required this.AdoptionStatus,
    required this.ArrivalDate,
  });

  @primaryKey
  final int AnimalID;

  final String Name;
  final String Species;
  final String? Breed;
  final int? Age;
  final String Gender; // Could be enum but stored as string
  final String? Description;
  final String? PhotoUrl;
  final String AdoptionStatus; // Could be enum but stored as string
  final String ArrivalDate;
}

@entity
class Todo {
  Todo({required this.id, required this.name, this.checked = false});

  @primaryKey
  final int? id;

  final String name;
  bool checked;
}
