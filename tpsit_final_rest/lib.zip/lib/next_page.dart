import 'dart:convert';
import 'dart:ffi';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dao.dart';
import 'database.dart';
import 'model.dart';

String ip = "192.168.1.165";

class AnimalListWidget extends StatefulWidget {
  AnimalListWidget();

  @override
  _AnimalListWidgetState createState() => _AnimalListWidgetState();
}

class _AnimalListWidgetState extends State<AnimalListWidget> {
  late final AppDatabase database;
  late final UserDao userDao;
  late List<Animal> animals = [];
  String _searchUserId = '';

  @override
  initState() {
    super.initState();
    initdatabase();

    fetchAnimals().then((value) => setState(() {
          animals = value;
        }));
    fetchUsers();
  }

  Future<void> initdatabase() async {
    database = await $FloorAppDatabase.databaseBuilder('database.db').build();
    userDao = database.userDao;
  }

  Future<List<Animal>> fetchAnimals() async {
    var url = Uri.parse('http://' + ip + ':3000/api/animals');
    var response = await http.get(url);
    List<dynamic> data = jsonDecode(response.body);
    List<Animal> animals = data
        .map((animalJson) => Animal(
            AnimalID: animalJson['AnimalID'],
            Name: animalJson['Name'],
            Species: animalJson['Species'],
            Breed: animalJson['Breed'],
            Age: animalJson['Age'],
            Gender: animalJson['Gender'],
            Description: animalJson['Description'],
            PhotoUrl: animalJson['PhotoUrl'],
            AdoptionStatus: animalJson['AdoptionStatus'],
            ArrivalDate: animalJson['ArrivalDate']))
        .toList();
    return animals;
  }

  Future<void> fetchUsers() async {
    var url = Uri.parse('http://' + ip + ':3000/api/users');
    var response = await http.get(url);
    List<dynamic> data = jsonDecode(response.body);
    for (var element in data) {
      var supercontrol =
          await userDao.findUserById(int.parse(element['UserID'].toString()));
      if (supercontrol == null) {
        User user = User(
          UserID: int.parse(element['UserID'].toString()),
          username: element['username'],
          Email: element['Email'],
          PasswordHash: element['PasswordHash'],
          isAdmin: element['isAdmin'] == 1,
          RegistrationDate: element['RegistrationDate'],
        );
        await userDao.insertUser(user);
      }
    }
  }

  Future<List<Animal>> get _filteredAnimals async {
    if (_searchUserId.isEmpty) {
      return animals;
    } else {
      List<Animal> filteredList = [];
      for (var animal in animals) {
        final idUser = animal.AnimalID;
        int control = int.parse(animal.AnimalID.toString());
        final user = await getUserById(control);
        if (user != null && user.username.contains(_searchUserId)) {
          filteredList.add(animal);
        }
      }
      return filteredList;
    }
  }

  Future<User?> getUserById(int idUser) async {
    final user = await userDao.findUserById(idUser);
    return user;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Animals'),
        ),
        body: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TextField(
                onChanged: (value) {
                  setState(() {
                    _searchUserId = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Search by Username',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Expanded(
              child: FutureBuilder<List<Animal>>(
                future: _filteredAnimals,
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else if (snapshot.hasError) {
                    return Text('Error: ${snapshot.error}');
                  } else {
                    return ListView.builder(
                      itemCount:
                          snapshot.data != null ? snapshot.data?.length : 0,
                      itemBuilder: (context, index) {
                        if (snapshot.data != null) {
                          return AnimalCard(animal: snapshot.data![index]);
                        }
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ));
  }
}

class AnimalCard extends StatelessWidget {
  final Animal animal;

  AnimalCard({required this.animal});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      margin: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: CachedNetworkImage(
              imageUrl: animal.PhotoUrl ?? '',
              fit: BoxFit.cover,
              height: 200.0,
              width: double.infinity,
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              animal.Description ?? '',
              style: TextStyle(fontSize: 16.0),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(8.0, 0.0, 8.0, 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  animal.ArrivalDate,
                  style: TextStyle(fontSize: 12.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
