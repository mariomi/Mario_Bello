document.addEventListener('DOMContentLoaded', function() {
    const userButton = document.getElementById('userButton');

    // Fetch the logged-in user's name
    fetch('http://localhost:3000/api/users/profile')
        .then(response => response.json())
        .then(user => {
            const userName = user.data.Username || 'X';  // Default to 'X' if no user is logged in
            if (userButton && userName) {
                userButton.textContent = userName.charAt(0).toUpperCase();
            }
        })
        .catch(error => {
            console.error('Error fetching user:', error);
            if (userButton) {
                userButton.textContent = 'X';  // Default to 'X' if there is an error
            }
        });

    const animalList = document.getElementById('animal-list');

    // Fetch all available animals
    fetch('http://localhost:3000/api/animals')
        .then(response => response.json())
        .then(animals => {
            animalList.innerHTML = ''; // Svuota la lista degli animali
            animals.forEach(animal => {
                const div = document.createElement('div');
                div.className = 'animal';
                div.style.cursor = 'pointer';

                // Utilizza direttamente l'URL dell'immagine
                const imgUrl = animal.PhotoUrl ? animal.PhotoUrl : 'assets/images/fallback.jpg';

                div.innerHTML = `
                    <img style="display: block; -webkit-user-select: none; margin: auto; cursor: zoom-in; background-color: #1c1c1c; transition: background-color 300ms; width: 100%; height: 200px; object-fit: cover;" src="${imgUrl}" alt="Foto di ${animal.Name}" onerror="this.onerror=null;this.src='assets/images/fallback.jpg';">
                    <h3>${animal.Name}</h3>
                    <p>Specie: ${animal.Species}</p>
                    <p>Età: ${animal.Age}</p>
                `;

                div.addEventListener('click', () => {
                    window.location.href = `animal.html?id=${animal.AnimalID}`;
                });

                animalList.appendChild(div);
            });
        })
        .catch(error => console.error('Error loading the animals:', error));
});
