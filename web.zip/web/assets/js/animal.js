document.addEventListener('DOMContentLoaded', function() {
    const userButton = document.getElementById('userButton');
    const animalDetails = document.getElementById('animal-details');
    const adoptButton = document.getElementById('adopt-button');
    const params = new URLSearchParams(window.location.search);
    const animalId = params.get('id');

    // Fetch the logged-in user's name
    fetch('http://localhost:3000/api/users/profile')
        .then(response => response.json())
        .then(user => {
            const userName = user.data.Username || 'X';  // Default to 'X' if no user is logged in
            if (userButton && userName) {
                userButton.textContent = userName.charAt(0).toUpperCase();
            }
        })
        .catch(error => {
            console.error('Error fetching user:', error);
            if (userButton) {
                userButton.textContent = 'X';  // Default to 'X' if there is an error
            }
        });

    // Fetch animal details
    fetch(`http://localhost:3000/api/animals/${animalId}`)
        .then(response => response.json())
        .then(animal => {
            if (animal && animal.PhotoUrl && animal.Name) {
                animalDetails.innerHTML = `
                    <img src="${animal.PhotoUrl}" alt="Foto di ${animal.Name}" style="width: 100%; height: auto;">
                    <h1>${animal.Name}</h1>
                    <p>Specie: ${animal.Species}</p>
                    <p>Razza: ${animal.Breed}</p>
                    <p>Età: ${animal.Age}</p>
                    <p>Descrizione: ${animal.Description}</p>
                `;
            } else {
                animalDetails.innerHTML = `<p>Animal details could not be loaded.</p>`;
            }

            adoptButton.addEventListener('click', () => adoptAnimal(animalId));
        })
        .catch(error => {
            console.error('Error loading the animal details:', error);
            animalDetails.innerHTML = `<p>Error loading the animal details.</p>`;
        });

    function adoptAnimal(animalId) {
        fetch('http://localhost:3000/api/users/profile')
            .then(response => {
                if (!response.ok) {
                    window.location.href = `login.html?redirect=animal.html?id=${animalId}`;
                } else {
                    return response.json();
                }
            })
            .then(user => {
                fetch(`http://localhost:3000/api/animals/adopt/${animalId}`, { method: 'POST' })
                    .then(response => {
                        if (response.ok) {
                            alert('Animal adopted successfully!');
                            window.location.href = 'adoptions.html';
                        } else {
                            alert('Failed to adopt animal.');
                        }
                    });
            })
            .catch(error => console.error('Error during adoption process:', error));
    }
});
