document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    console.log('Token retrieved from localStorage:', token); // Log di debug
  
    if (!token) {
      console.log('No token found in localStorage, redirecting to login page'); // Log di debug
      window.location.href = 'login.html';
      return;
    }
  
    try {
      // Fetch all adoptions
      console.log('Fetching all adoptions...'); // Log di debug
      const response = await fetch('http://localhost:3000/api/adoptions', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
  
      console.log('Adoptions response status:', response.status); // Log di debug
      console.log('Adoptions response headers:', response.headers); // Log di debug
  
      const contentType = response.headers.get("content-type");
      if (!contentType) {
        console.error('Adoptions response does not have a content-type header'); // Log di debug
        throw new TypeError("Adoptions response does not have a content-type header");
      }
  
      if (!contentType.includes("application/json")) {
        console.error('Adoptions response is not JSON, content-type:', contentType); // Log di debug
        throw new TypeError("Adoptions response is not JSON");
      }
  
      const data = await response.json();
      console.log('Adoptions response data:', data); // Log di debug
  
      if (response.ok) {
        const adoptionsContainer = document.getElementById('adoptionsContainer');
        adoptionsContainer.innerHTML = data.map(adoption => `
          <div class="adoption">
            <h3>Animal ID: ${adoption.AnimalID}</h3>
            <p>Status: ${adoption.Status}</p>
          </div>
        `).join('');
      } else {
        console.error('Failed to fetch adoptions:', data.message); // Log di debug
        document.getElementById('adoptionsContainer').innerText = data.message;
      }
    } catch (error) {
      console.error('Error during fetching adoptions:', error); // Log di debug
      document.getElementById('adoptionsContainer').innerText = 'An error occurred while fetching the adoptions.';
    }
  });
  